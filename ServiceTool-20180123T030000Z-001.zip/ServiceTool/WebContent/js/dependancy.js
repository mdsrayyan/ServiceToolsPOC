function dependancySave() {
	//alert(cat);
	
	
/*alert("category :: "+category);
alert("role :: "+role);
alert("status :: "+status);
alert("searchUser :: "+searchUser);*/
	var id="hi";
	alert("id"+id);
  
	$.ajax({
		type : "GET",
		url : "/ServiceTool/getTaskList.html",
		data : "&id=" + id,
		success : function(response) {
			alert(response);
			
		},
		error : function(e) {
			alert('Error ! ' + 'Unable to retrieve data' + e);
			return;
		}
	});
	
}