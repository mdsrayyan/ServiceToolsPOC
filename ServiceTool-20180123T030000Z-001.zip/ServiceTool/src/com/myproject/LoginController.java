package com.myproject;


import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class LoginController {
	
	
	/*@RequestMapping(value = "login", method = RequestMethod.POST)
	public String validateLogin(@Valid @ModelAttribute("login") UserLogin userFromForm,
			BindingResult result, ModelMap model, final RedirectAttributes redirectSessAttribs) {
		System.out.println("In the class");	
		
		return "";
	
	}*/
	
	@RequestMapping(value="/login", method = RequestMethod.GET)
    public String showLogin(HttpServletRequest request,@ModelAttribute("login") UserLogin user,
    		BindingResult result,ModelMap map) throws Exception {

		System.out.println("inside get login");
		//ModelAndView mav = new ModelAndView();;
		//request.getSession().invalidate();	
      //  mav.addObject("login",map);
        return "login";

	}  
	
	@RequestMapping(value = "getTaskList", method = RequestMethod.GET)
	public @ResponseBody String createUserList(@RequestParam(required = false, value = "id")String id
			)
	{
		System.out.println("id"+id);
		
		return "get lost";
	}


}
